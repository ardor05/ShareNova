export const LOCAL_STORAGE_PREFIX = 'ContentCreator';
