export function rlcToNrlc(rlcValue: number) {
  return rlcValue * 10 ** 9;
}
